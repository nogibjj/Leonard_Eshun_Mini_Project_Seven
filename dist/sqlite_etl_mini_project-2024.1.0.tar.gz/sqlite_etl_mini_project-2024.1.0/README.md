# Data Engineering Mini Project Seven

[![CI](https://github.com/nogibjj/Leonard_Eshun_Mini_Project_Seven/actions/workflows/workflow.yml/badge.svg)](https://github.com/nogibjj/Leonard_Eshun_Mini_Project_Seven/actions/workflows/workflow.yml)


This repository is created as an assignment from the Data Engineering course, IDS 706. The aim is to package a python script into a command-line tool.

The requirements are:
1. Package a Python script with setuptools or a similar tool
1. Include a user guide on how to install and use the tool
1. Do the standard CI/CD setup
1. Include communication with an external or internal database (NoSQL, SQL, etc)


## The functions and what they do

1. **extract** to extract the read an external csv file via its url and save to file in the /data folder using the name you give it. The database will be created if it doesn't exist.

1. **transform_n_load** to create a number of tables in the SQLite database based on the table structures you give it for transformation, then saves the content of the csv file to the tables you created. 

1. **read_data** to read one data from the SQLite database based on the record id you give it.

1. **read_all_data** to read all the records from the SQLite database.	

1. **save_data** to save records to a table you give it, following the table column structure.

1. **delete_data** to delete a record from the database given a record ID.

1. **update_data** to update a record in the database using the table columns and a record ID.

1. **get_table_columns** to get the column names of a table. This is useful for saving and updating.


## CLI Integration
The main.py script provides a CLI allowing the ETL and CRUD operations to be done from the command line. 

To use the commands, install the package by running the command:

At the cli prompt, type:
```
pip install "path_to_the_package_file"
```

Where "path_to_the_package_file" is the path to the package file for distributing this application and ends in _tar.gz_.

After installation, at the cli command prompt, type:
```
sqlite_etl "command" "arguments"
```

The list of CRUD and related commands this package can execute are:
1. extract
1. transform_n_load
1. read_data
1. read_all_data
1. save_data
1. update_data
1. delete_data
1. get_table_columns

[Please find a User Manual on the parameters and how to use them here]("User Manual.md")

> [!IMPORTANT]
> It's important to provide the arguments in the order and formats as desribed above for the CLI to work.

## Log of successful operations
The test operation saved its steps to a log file to show the success of the operations.

[Please find the file here](Test_Log.md)


## Steps taken to implement the Package 


## Interesting discoveries


## References
[Official Setuptools Quick Start](https://setuptools.pypa.io/en/latest/userguide/quickstart.html)
[Official Setuptools more details](https://setuptools.pypa.io/en/latest/userguide/pyproject_config.html)

**Alternative to the official steps** 
[text](https://carpentries-incubator.github.io/python_packaging/03-building-and-installing.html)
[text](https://xebia.com/blog/an-updated-guide-to-setuptools-and-pyproject-toml/)

**Useful for adding data and other files to the package** 
[text](https://setuptools.pypa.io/en/latest/userguide/datafiles.html)
[text](https://setuptools.pypa.io/en/latest/userguide/miscellaneous.html)

